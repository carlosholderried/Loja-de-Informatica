
package testes;

import java.util.Scanner;
import produtos.Produtos;
import produtos.Impressora;
import produtos.Notebooks;

public class Teste {

	public static void main(String[] args) {

/*	
		Produtos geral ;
		
		Produtos[] osProd = new Produtos[5];
		
		osProd[0] = new Gerente("Jo�o","23847");
		osProd[1] = new Secretario("Jos�","567567");
		osProd[2] = new Diretor("Otavio","567567");
		osProd[3] = new Gerente("Maria","567567");
		osProd[4] = new Caixa("Josefa","567567");
		

		

*/		

		
		
		
//		for(int i=0 ; i<5 ; i++)
//		{
//			System.out.println(osFuncionarios[i].toString()+" bonificacao: "+
//		                       osFuncionarios[i].getBonificacao());
//		}
		
		
//		Gerente gerente1 = new Gerente("Jo�o","23847");
//		Secretario secretario1 = new Secretario("Jos�","567567");
//		
//		geral = gerente1;
//		
//		geral.toString();
//		
//		// O erro acontece por causa da maneira como o Compilador lida com tipos
//		// O Compilador sempre olha o tipo da vari�vel para decidir se o c�digo est� corretamente escrito
		
	}

}
