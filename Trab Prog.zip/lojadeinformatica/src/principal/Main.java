package principal;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}

/*
Loja de Inform�tica
Crie uma hierarquia de classes para representar cada Produto em uma loja de 
equipamentos de inform�tica.

As categorias de produtos vendidos s�o:

Notebook
Impressora
S�o registradas e mantidas as seguintes informa��es sobre estes produtos

Para todos eles: marca e pre�o de custo
Notebooks: capacidade de mem�ria e tamanho da tela
Impressoras: n�mero de p�ginas por minuto (ppm)
O �pre�o final� de cada produto � retornado pelo m�todo 

double precoFinal()
para determinar o pre�o final seguimos as seguintes regras de neg�cio:

Para Notebook : pre�o de custo + 20%
Para Impressora : pre�o de custo + { 20% se ppm < 20 e 30% se ppm >= 20)
Monte uma estrutura de classes para representar estes objetos considerando as seguintes 
situa��es:

Cada categoria de produto deve ser representada em uma classe
Use uma hierarquia incluindo uma classe Produto no projeto
Mantenha o encapsulamento
Inclua construtores para todas as classes implementadas, inicializando os atributos
Todo objeto produto deve implementar o m�todo 

String toString() ;
para retornar um String incluindo as seguintes informa��es:

Para Notebook : a palavra �notebook� + capacidade de mem�ria e tamanho da tela
Para Impressora : a palavra �impressora� + n�mero de p�ginas por minuto
Implemente uma interface de usu�rio para SOMENTE

Cadastrar produtos de forma que todos (impressoras e notebooks) sejam armazenados em uma 
�nica estrutura de dados (array ou ArrayList)
A interface deve permitir o cadastramento de Notebooks e Impressoras separadamente.
Mostrar todos os produtos cadastrados: para cada produto , � apresentado o String 
produzido pelo m�todo toString().
Mostrar todos os produtos cadastrados com �pre�o final� abaixo de um valor informado 
pelo usu�rio.
O usu�rio informa o valor e, para todos os produtos com �pre�o final� abaixo do valor 
informado, � apresentado o String produzido pelo m�todo toString() e o �pre�o final�.
*/

